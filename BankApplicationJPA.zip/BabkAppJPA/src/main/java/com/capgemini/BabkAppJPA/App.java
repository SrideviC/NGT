package com.capgemini.BabkAppJPA;

import java.util.Scanner;
import com.capgemini.bean.Account;
import com.capgemini.bean.Loan;
import com.capgemini.bean.Transaction;
import com.capgemini.dao.BankDao;
import com.capgemini.validation.Validation;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        //System.out.println( "Hello World!" );
    	String name, id, address, loanId, loanType;
		double deposit, withdraw, loanAmount;
		
		BankDao dao = new BankDao();
		Validation vd = new Validation();
		Transaction transaction = new Transaction();


		while (true) {
			
			System.out.println("1. Open the Account");
			System.out.println("2. Deposit Amount");
			System.out.println("3. Withdraw AMount");
			System.out.println("4. Apply Loan");
			System.out.println("5. Show Account Details");
			System.out.println("6. Pay Loan");
			System.out.println("7. Show Loan Details");
			System.out.println("8. Exit");

			Scanner scanner = new Scanner(System.in);
			System.out.println("Enter option");
			int option = scanner.nextInt();

			switch (option) 
			{
			case 1: 
			{
				while (true) 
				{
					
					System.out.println("Enter your Name (First letter Capital)");
					name = scanner.next();
					if (vd.validateAccountName(name)) 
					{
						System.out.println("Enter your Account Id (eg. 1234567-ABCD)");
						id = scanner.next();
						if (vd.validateAccountId(id))
						{
							System.out.println("Enter your Address");
							address = scanner.next();
							System.out.println("Enter Deposit Amount");
							deposit = scanner.nextDouble();
							Account acc = new Account(id, name, address, deposit);
							dao.createAccount(acc);
							break;
						} else 
						{
							System.out.println("Please enter valid Id");
						}
					} else
						System.out.println("Please enter valid name ");
				}
				break;
			}
				
			case 2: 
			{
				
				System.out.println("Enter your Account Id and Amount");
				id = scanner.next();
				deposit = scanner.nextDouble();
				double bal=dao.deposit(id,deposit);
				System.out.println("New balance :"+bal);
				break;
			}
			
		
			case 3: 
			{
				System.out.println("Enter Account Id and Amount");
				id = scanner.next();
				withdraw = scanner.nextDouble();
				System.out.println("New balance after withdrawl is: " +dao.withdraw(id, withdraw));
				break;
			}
			
			case 4: 
			{
				System.out.println("Enter your Account Id");
				id = scanner.next();
				System.out.println("Enter Loan Id");
				loanId = scanner.next();
				if (id.equals(loanId)) {
					System.out.println("Select Loan Type :");
					loanType = scanner.next();
					System.out.println("Enter loan amount");
					loanAmount = scanner.nextDouble();
					Loan loan = new Loan(loanId, loanType, loanAmount);
					dao.applyLoan(loan);
					break;
				} else
					System.out.println("Invalid Loan Id");
				break;
			}
			
			case 5: 
			{
				System.out.println("Enter your Account Id");
				Account acc =dao.getAccDetails(scanner.next());
				break;

			}
			case 6: 
			{
				System.out.println("Enter your  Account Id");
				id = scanner.next();
				System.out.println("Enter Loan Id");
				loanId = scanner.next();
				System.out.println("Enter amount to pay");
				loanAmount = scanner.nextDouble();
				double bal = dao.payLoan(id, loanAmount);
				System.out.println("paid loan amount "+bal);
				break;
			}
			
			case 7:
			{
				System.out.println("Enter loan Id");
				Loan loan =dao.getLoanDetails(scanner.next());
				loanId = scanner.next();
				break;

			}
			case 8: 
			{
				System.exit(0);
			}
			default:
				System.out.println("Please enter correct choice");
			}
		}
    }
}
