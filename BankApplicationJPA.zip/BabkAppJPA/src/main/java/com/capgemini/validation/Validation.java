package com.capgemini.validation;

public class Validation {
	
	public boolean validateAccountName(String accountName) {
		String pattern="^[a-zA-Z]*$";
        return accountName.matches(pattern);
	}

	public boolean validateAccountId(String accountId) {
		 String pattern="^[1-9]{7}-[A-Z]{4}$";
			return accountId.matches(pattern);	
		
	}

}
