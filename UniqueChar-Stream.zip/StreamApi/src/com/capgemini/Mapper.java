package com.capgemini;

import java.util.ArrayList;
import java.util.function.Function;

public class Mapper {
	
	Function<String,  CharactersCount> getDistinctCharactersCount(){
		return c->{
			ArrayList<Character> unique = new ArrayList<Character>();
		     for( int i = 0; i < c.length(); i++) {
		         if( !unique.contains( c.charAt( i ) ) ) {
		             unique.add( c.charAt( i ) );
		         }
		     }
		     return new CharactersCount(c, unique.size());
			};
		
		

}
}