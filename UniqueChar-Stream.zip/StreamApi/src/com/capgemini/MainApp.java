package com.capgemini;

import java.util.Arrays;
import java.util.List;

public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Filter filter = new Filter();
		Mapper mapper = new Mapper();
		List<String> l = Arrays.asList("aaryanna", "aayanna", "airianna", "alassandra", "allanna", "allannah",
		                                "allessandra", "allianna", "allyanna", "anastaisa", "anastashia", "anastasia", "annabella", "annabelle",
		                                "annebelle");
		l.stream()
		.filter(filter.nameStartingWithPrefix("aa"))
		.map(mapper.getDistinctCharactersCount())
		.forEach(System.out::println);
		
		
		

	}

}
