package com.capgemini.main;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiPredicate;
import java.util.stream.Stream;

import com.capgemini.bean.XData;
import com.capgemini.bean.YData;

public class DataReconcile {

	public static void main(String[] args) throws IOException {
		
		String file1 = "C:\\Users\\mahes\\OneDrive\\Desktop\\x.txt";
		String file2 = "C:\\Users\\mahes\\OneDrive\\Desktop\\y.txt";
		
		Stream<String> stream1 = Files.lines(Paths.get(file1));
		Stream<String> stream2 = Files.lines(Paths.get(file2));
		
		String[] arr1 = stream1.toArray(size -> new String[size]);
		String[] arr2 = stream2.toArray(size -> new String[size]);
		 
		 List<String> exact = new ArrayList<>();
	     List<String> weak = new ArrayList<>();
	     List<String> break1 = new ArrayList<>();
	        
		
		XData[] data = new XData[10];
		for(int i =0;i< arr1.length; i++)
		{
			data[i] = new XData();
		}
		
		
	  for(int i =0; i< arr1.length ; i++ ) 
	  {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(" d-MMM-yyyy");
		String[] subArray =  arr1[i].split(";");
		data[i].setAcc_Id(subArray[0]);
		data[i].setTrans_Id(subArray[1]);
		data[i].setPostingDate(LocalDate.parse(subArray[2],formatter));
		data[i].setAmnt(subArray[3]);
    	}
	  
	 YData[] dataY = new YData[10];
		
		for(int i =0;i< arr1.length; i++)
		{
			dataY[i] = new YData();
		}
		
		
	  for(int i = 0; i< arr1.length ; i ++ ) 
	  {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(" d-MMM-yyyy");
		String[] subArray =  arr2[i].split(";");
		dataY[i].setAcc_Id(subArray[0]);
		dataY[i].setTrans_Id(subArray[1]);
		dataY[i].setPostingDate(LocalDate.parse(subArray[2],formatter));
		dataY[i].setAmnt(subArray[3]);
  	}
	  
		BiPredicate<XData, YData> filterTrans = (x, y) -> {
            return x.getTrans_Id().contains(y.getTrans_Id());
        };
          
		BiPredicate<XData, YData> filterdate = (x, y) -> {
		Period period = Period.between(x.getPostingDate(),y.getPostingDate());			
	 if(((x.getPostingDate().getDayOfWeek()) == DayOfWeek.SATURDAY ) && y.getPostingDate().getDayOfWeek() == DayOfWeek.SUNDAY)
			{
				return(period.getDays() == 0);
			}
		else {	
		    return (period.getDays() < 1);
			 }
        };		
          
           BiPredicate<XData, YData> filterAmount = (x, y) -> {
        	double d1=Double.parseDouble(x.getAmnt());
        	double d2=Double.parseDouble(y.getAmnt());
           	if(d1 > d2) {
           	return (d1-d2 <= 0.01);
           	}
           	else if(d2 >d1) {
           	return (d2-d1 <= 0.01);
           	}
           	else 
           	return (d2-d1 == 0);
        };	              
     
        for(int q = 0; q < 8;q++) 
        {
        	BiPredicate<XData,YData> combineAll = filterTrans.and(filterAmount).and(filterdate);
        	boolean result= combineAll.test(data[q], dataY[q]);
        	if(result == true)
        	{
        		exact.add(data[q].getAcc_Id());
        	    exact.add(dataY[q].getAcc_Id());
            } 
        	else {
        		BiPredicate<XData, YData> combine = filterTrans.negate().or(filterAmount);         
                boolean result1 = combine.test(data[q], dataY[q]);
                if(result1 == true) {
                	break1.add(data[q].getAcc_Id());
                	break1.add(dataY[q].getAcc_Id());
                	}
                else {
                	weak.add(data[q].getAcc_Id());
        	        weak.add(dataY[q].getAcc_Id());
        	        }
                }
        	}
        
        System.out.println("Exact Matches");
        for(String e: exact)
        {
        	System.out.print(e+ " ");
        }
        System.out.println();
        System.out.println("Weak Matches");
        for(String e: weak)
        {
        	System.out.print(e + " ");
        }
        System.out.println();
        System.out.println("Break Matches");
        for(String e: break1)
        {
        	System.out.print(e + " ");
        }
	}
}
