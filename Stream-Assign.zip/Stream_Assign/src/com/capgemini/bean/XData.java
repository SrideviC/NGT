package com.capgemini.bean;

import java.time.LocalDate;

public class XData {
	
	private String trans_Id;
	private String acc_Id;
	private LocalDate postingDate;
	private String amnt;
	
	public XData() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getTrans_Id() {
		return trans_Id;
	}

	public void setTrans_Id(String trans_Id) {
		this.trans_Id = trans_Id;
	}

	public String getAcc_Id() {
		return acc_Id;
	}

	public void setAcc_Id(String acc_Id) {
		this.acc_Id = acc_Id;
	}

	public LocalDate getPostingDate() {
		return postingDate;
	}

	public void setPostingDate(LocalDate postingDate) {
		this.postingDate = postingDate;
	}

	public String getAmnt() {
		return amnt;
	}

	public void setAmnt(String amnt) {
		this.amnt = amnt;
	}

	@Override
	public String toString() {
		return "XData [trans_Id=" + trans_Id + ", acc_Id=" + acc_Id + ", postingDate=" + postingDate + ", amnt=" + amnt
				+ "]";
	}
	
	

}
