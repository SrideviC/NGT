package com.capgemini.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.model.Book;
import com.capgemini.model.Library;
import com.capgemini.repository.BookRepository;
import com.capgemini.repository.LibraryRepository;
import com.capgemini.service.LibService;

@Controller
public class LibController {
	
	@Autowired
	LibraryRepository libRepo;
	
	@Autowired
	BookRepository bookRepo;
	
	@Autowired
	LibService libService;
	
	Book book;
	
	Library lib;
	
	@RequestMapping("/")
	public String index()
	{
		System.out.println("index");
		return "index.jsp";
	}
	
	@PostMapping(value="/addBook")
	@ResponseBody
	public String addBook(Library library,Book book)
	{			
		
		book.setLibrary(library);
		library.getBook().add(book);
		libRepo.save(library);
		return "added";
		
	}
	
	@DeleteMapping(value="/deleteBook")
	@ResponseBody
	public String deleteBook(@RequestParam int deletebid) 
	{
		libService.deleteBook(deletebid);
		return "Deleted";
	}
	
	@RequestMapping(value="/searchBook",method=RequestMethod.GET)
	public ModelAndView searchBook(@RequestParam int libraryId,@RequestParam int bookId) 
	{
		ModelAndView mv=new ModelAndView("SearchLib.jsp");
		Library library=libService.findBook(libraryId);
		Book book=libService.findBookId(bookId);
		mv.addObject(library);
		mv.addObject(book);
		return mv;
	}
		
	
	@PutMapping(value="/updateBook")
	public ModelAndView updateBook(@RequestParam int bookid,@RequestParam String bookName,@RequestParam String author,@RequestParam String publisher) 
	{
		ModelAndView mv=new ModelAndView("Updated.jsp");
		Book book=libService.updateBookDetails(bookid,bookName,author,publisher);
		mv.addObject(book);
		return mv;
	}
	
}
