package com.capgemini.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.model.Book;
import com.capgemini.model.Library;
import com.capgemini.repository.BookRepository;
import com.capgemini.repository.LibraryRepository;

@Service
public class LibService {

	@Autowired
	LibraryRepository libRepo;

	@Autowired
	BookRepository bookRepo;

	public void deleteBook(Integer bookId) {
		libRepo.deleteById(bookId);
	}

	public Library findBook(Integer libraryId) {

		Optional<Library> optional = libRepo.findById(libraryId);
		Library library = optional.get();
		return library;

	}

	public Book findBookId(Integer bookId) {

		 //return bookRepository.findById(bookId);

		Optional<Book> optional = bookRepo.findById(bookId);
		Book book = optional.get();
		return book;

	}

	public Book updateBookDetails(int nbId, String nBName, String nBauthr, String nBpubshr) {
		// TODO Auto-generated method stub
		
		Book b =findBookId(nbId);
		
	    b.setBookName(nBName);
		b.setAuthor(nBauthr);
		b.setPublisher(nBpubshr);
		bookRepo.save(b);
		return b;
	}
}
