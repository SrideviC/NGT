package com.capgemini.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.model.Library;

public interface LibraryRepository extends JpaRepository<Library, Integer>{

}
