package com.capgemini.bean;

public class Product {
	
	private int productId;
	private String productName;
	private int noOfItems;
	private double costOfItem;
	private ProductType productType;
	
	
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Product(int productId, String productName, int noOfItems, double costOfItem, ProductType productType) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.noOfItems = noOfItems;
		this.costOfItem = costOfItem;
		this.productType = productType;
		
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getNoOfItems() {
		return noOfItems;
	}

	public void setNoOfItems(int noOfItems) {
		this.noOfItems = noOfItems;
	}

	public double getCostOfItem() {
		return costOfItem;
	}

	public void setCostOfItem(double costOfItem) {
		this.costOfItem = costOfItem;
	}

	public ProductType getProductType() {
		return productType;
	}

	public void setProductType(ProductType productType) {
		this.productType = productType;
	}

	
	
	
	

}
