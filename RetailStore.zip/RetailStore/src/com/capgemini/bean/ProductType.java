package com.capgemini.bean;

public enum ProductType {
	
	GROCERIES,
	APPLIANCES;
	

}
