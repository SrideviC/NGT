package com.capgemini.bean;

public enum UserType {
	
	EMPLOYEE,
	AFFILIATE,
	CUSTOMER;

}
