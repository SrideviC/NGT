package com.capgeimini.bean;

import java.time.LocalDate;

public class Employee {
	private String EmployeeId;
	private String firstName;
	private String LastName;
	private Double Salary;
	private String DOJ;
	private Department department;
	private Address address;
	
	
	public String getEmployeeId() {
		return EmployeeId;
	}


	public void setEmployeeId(String employeeId) {
		EmployeeId = employeeId;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return LastName;
	}


	public void setLastName(String lastName) {
		LastName = lastName;
	}


	public Double getSalary() {
		return Salary;
	}


	public void setSalary(Double salary) {
		Salary = salary;
	}


	public String getDOJ() {
		return DOJ;
	}


	public void setDOJ(String string) {
		DOJ = string;
	}


	public Department getDepartment() {
		return department;
	}


	public void setDepartment(Department department) {
		this.department = department;
	}


	public Address getAddress() {
		return address;
	}


	public void setAddress(Address address) {
		this.address = address;
	}
     
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(String employeeId, String firstName, String lastName, Double salary, String dOJ,
			Department department, Address address) {
		super();
		EmployeeId = employeeId;
		this.firstName = firstName;
		LastName = lastName;
		Salary = salary;
		DOJ = dOJ;
		this.department = department;
		this.address = address;
	}


	@Override
	public String toString() {
		return "Employee [EmployeeId=" + EmployeeId + ", firstName=" + firstName + ", LastName=" + LastName
				+ ", Salary=" + Salary + ", DOJ=" + DOJ + ", department=" + department + ", address=" + address + "]";
	}
    
	
	

	
}
