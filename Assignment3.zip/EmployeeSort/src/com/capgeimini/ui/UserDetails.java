package com.capgeimini.ui;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.capgeimini.bean.Address;
import com.capgeimini.bean.Department;
import com.capgeimini.bean.Employee;
import com.capgeimini.data.EmployeeData;
import com.capgeimini.validate.Validation;

import java.util.Map.Entry;

	public class UserDetails {
		public static void main(String[] args) {
			
			Scanner sc=new Scanner(System.in);
			Validation validation=new Validation();
			EmployeeData data=new EmployeeData();
			Department dept =new Department();
			Address address = new Address();
			
			while (true) {
				
				System.out.println("Choose any one");
				System.out.println("1. Add Employee");
				System.out.println("2. Sort by EmployeeId");
				System.out.println("3. Sort by FirstName");
				System.out.println("4. Sort by LastName");
				System.out.println("5. Sort by Salary");
				System.out.println("6. Sort by Address");
				System.out.println("7. Sort by Department");
				System.out.println("8. Exit");
			
				int choice = sc.nextInt();
				switch (choice) {
				case 1:
					Employee emp=new Employee();
					System.out.println("Enter employee id");
					
					while (true) {
							String employeeId=sc.next();
							if (validation.validateEmployeeId(employeeId)) {
								if(!data.map.containsKey(employeeId)) {
								emp.setEmployeeId(employeeId);
								break;
								}
								else {
									System.out.println("Enter unique Employee ID");
								}
							}
							else
								System.out.println("Enter valid Employee ID");
						}
					
					System.out.println("Enter first name");
					
					while (true) {
						String firstname=sc.next();
						if (validation.validateName(firstname)) {
								emp.setFirstName(firstname);
					            break;
						}
						else
							System.out.println("Enter name in alphabets");
					}
					System.out.println("Enter last name");
					
					while (true) {
						String lastname=sc.next();
						if (validation.validateName(lastname)) {
							emp.setLastName(lastname);
						    break;
						}
						else
							System.out.println("Enter name in alphabets");
					}
					
					System.out.println("Enter employee salary");
					while (true) {
						Double salary=sc.nextDouble();
						if (validation.validateSalary(salary)) {
							emp.setSalary(salary);
							break;
						}
						else
							System.out.println("Enter salary between 20000 and 5Lakhs");
					}
					System.out.println("Enter the date of joining");
					emp.setDOJ(sc.next());
					
					System.out.println("Enter Department ID");
					dept.setDepartmentId(sc.nextInt());
					System.out.println("Enter Department Name");
			        dept.setDepartmentName(sc.next());
					System.out.println("Enter Department Location");
					dept.setLocation(sc.next());
					emp.setDepartment(dept);
					
						
					System.out.println("Please Enter Address ID:");
					address.setAddressId(sc.next());
				    System.out.println("Please Enter Address Line 1:");
					address.setAddressLine1(sc.nextLine());
				    System.out.println("Please Enter City:");
					address.setCity(sc.next());
					System.out.println("Please Enter State:");
				    address.setState(sc.next());
					emp.setAddress(address);
						
					data.map.put(emp.getEmployeeId(), emp);
					System.out.println("Employee created"+data.map);
					break;
					
				case 2:
					Set<Entry<String,Employee>>entrySet1=data.map.entrySet();
					List<Entry<String,Employee>> list1=new ArrayList<Map.Entry<String,Employee>>(entrySet1);
					Collections.sort(list1, new Comparator<Entry<String,Employee>>() {

						@Override
						public int compare(Entry<String, Employee> o1, Entry<String, Employee> o2) {
							
							return o1.getValue().getEmployeeId().compareTo(o2.getValue().getEmployeeId());
						}
					});
					System.out.println("Sorted based on emp id");
					list1.forEach(s->{
						System.out.println("\t"+s.getValue().getEmployeeId()+"\t"+s.getValue().getFirstName());
					});
					 break;
				case 3:{
					Set<Entry<String,Employee>>entrySet=data.map.entrySet();
					List<Entry<String,Employee>> list=new ArrayList<Map.Entry<String,Employee>>(entrySet);
					Collections.sort(list, new Comparator<Entry<String,Employee>>() {

						@Override
						public int compare(Entry<String, Employee> o1, Entry<String, Employee> o2) {
							
							return o1.getValue().getFirstName().compareTo(o2.getValue().getFirstName());
						}
					});
					System.out.println("Sorted based on first name");
					list.forEach(s->{
						System.out.println(s.getKey()+"\t"+s.getValue().getFirstName());
					});
					break; 
				}
				case 4:{
					Set<Entry<String,Employee>>entrySet=data.map.entrySet();
					List<Entry<String,Employee>> list=new ArrayList<Map.Entry<String,Employee>>(entrySet);
					Collections.sort(list, new Comparator<Entry<String,Employee>>() {

						@Override
						public int compare(Entry<String, Employee> o1, Entry<String, Employee> o2) {
							
							return o1.getValue().getLastName().compareTo(o2.getValue().getLastName());
						}
					});
					System.out.println("Sorted based on last name");
					list.forEach(s->{
						System.out.println(s.getKey()+"\t"+s.getValue().getLastName());
					});
					break; 
				}
				case 5:{
					Set<Entry<String,Employee>>entrySet=data.map.entrySet();
					List<Entry<String,Employee>> list=new ArrayList<Map.Entry<String,Employee>>(entrySet);
					Collections.sort(list, new Comparator<Entry<String,Employee>>() {

						@Override
						public int compare(Entry<String, Employee> o1, Entry<String, Employee> o2) {
							
							return o1.getValue().getSalary().compareTo(o2.getValue().getSalary());
						}
					});
					System.out.println("Sorted based on salary");
					list.forEach(s->{
						System.out.println(s.getKey()+"\t"+s.getValue().getFirstName()+"\t"+s.getValue().getSalary());
					});
					break; 
				}
				case 6:{
					System.out.println("Sort By Address : ");
					Set<Entry<String,Employee>>entrySet=data.map.entrySet();
					List<Entry<String,Employee>> list=new ArrayList<Entry<String,Employee>>(entrySet);
					Collections.sort(list, new Comparator<Map.Entry<String,Employee>>() {

						@Override
						public int compare(Map.Entry<String, Employee> o1, Map.Entry<String, Employee> o2) {
							
							return o1.getValue().getAddress().getAddressId().compareTo(o2.getValue().getAddress().getAddressId());
						}
					});
					System.out.println("sorted based on addressid");
					 for (Entry<String,Employee> entry :list){
						System.out.println(entry.getValue().getAddress());
					};
					break; 
					
				}
				case 7:
					System.out.println("Sort By Department Name :");
					Set<Entry<String,Employee>>entrySet=data.map.entrySet();
					List<Entry<String,Employee>> list=new ArrayList<Entry<String,Employee>>(entrySet);
					Collections.sort(list, new Comparator<Map.Entry<String,Employee>>() {

						@Override
						public int compare(Map.Entry<String, Employee> o1, Map.Entry<String, Employee> o2) {
							
							return o1.getValue().getDepartment().getDepartmentName().compareToIgnoreCase(o2.getValue().getDepartment().getDepartmentName());
						}
					});
					System.out.println("sorted based on dept name");
					 for (Entry<String,Employee> entry :list){
						System.out.println(entry.getValue().getDepartment());
					};
					break; 
				case 8:System.out.println("Thank you!");
				break;
		}

	}
	}
		
	}