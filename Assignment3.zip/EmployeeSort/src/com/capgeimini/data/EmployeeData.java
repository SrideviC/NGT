package com.capgeimini.data;

import java.util.Map;
import java.util.TreeMap;

import com.capgeimini.bean.Employee;


public class EmployeeData {
	
	
	
	public Map<String,Employee> map;
	public EmployeeData() {
		map = new TreeMap<String,Employee>();
		
	}
	
}



/*
List<Employee> employees = new ArrayList<Employee>();

@Override
public void createEmployee(Employee emp) {
	employees.add(emp);
	System.out.println("Employee is created");
	
}

public List<Employee> getEmployees() {
	return employees;
}*/