package com.capgemini.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class ElectronicProduct {
	@Id
	private int code;
	private String name;
	private double price;
	private String image;
	private LocalDate createDate;
	
	public ElectronicProduct() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ElectronicProduct(int code, String name, double price, String image, LocalDate createDate) {
		super();
		this.code = code;
		this.name = name;
		this.price = price;
		this.image = image;
		this.createDate = createDate;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public LocalDate getCreateDate() {
		return createDate;
	}

	public void setCreateDate(LocalDate createDate) {
		this.createDate = createDate;
	}

	@Override
	public String toString() {
		return "ElectronicProduct [code=" + code + ", name=" + name + ", price=" + price + ", image=" + image
				+ ", createDate=" + createDate + "]";
	}
	
	
	
	
}
