package com.capgemini.bean;

public class Player {
	
	String name;
	String country;
	String Skill;
	
	public Player() {
		super();
	}
	
	public Player(String name, String country, String skill) {
		super();
		this.name = name;
		this.country = country;
		this.Skill = skill;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getSkill() {
		return Skill;
	}
	public void setSkill(String skill) {
		this.Skill = skill;
	}

	
	@Override
	public String toString() {
		return "Player [name=" + name + ", country=" + country + ", Skill=" + Skill + "]";
	}
}
