package com.capgemini.service;

import com.capgemini.bean.Match;
import com.capgemini.bean.Team;

public class MatchBO {
	
	public Match createMatch(String data, Team[] teamList) 
	{
		String matchinfo[] = data.split(",");
		Match match = new Match();
		match.setDate(matchinfo[0]);
		for(Team team : teamList) 
		{
			if(team.getName().equalsIgnoreCase(matchinfo[1]))
				match.setTeamOne(team);
		}
		for(Team team : teamList) 
		{
			if(team.getName().equalsIgnoreCase(matchinfo[2]))
				match.setTeamTwo(team);
		}
		match.setVenue(matchinfo[3]);
		return match;
	}
	
	public Team[] findTeam(String matchDate, Match[] matchList) 
	{
		Team teams[] = new Team[2];
		for(Match match : matchList) 
		{
			if(match.getDate().equals(matchDate)) 
			{
				teams[0] = match.getTeamOne();
				teams[1] = match.getTeamTwo();
			}
		}
		return teams;
	}
	
	public void findAllMatchesOfTeam(String teamName, Match[] matchList) 
	{
		for(Match match : matchList) 
		{
			if((match.getTeamOne().getName().equalsIgnoreCase(teamName)) || (match.getTeamTwo().getName().equalsIgnoreCase(teamName)))
				System.out.println(match);
			
		}
	}
	

}
