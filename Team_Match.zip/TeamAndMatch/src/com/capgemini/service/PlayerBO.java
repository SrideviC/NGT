package com.capgemini.service;

import com.capgemini.bean.Player;

public class PlayerBO {
	public Player createPlayer(String data) 
	{
		String player[] =  data.split(","); 
		return new Player(player[0], player[1], player[2]);
	}
}
