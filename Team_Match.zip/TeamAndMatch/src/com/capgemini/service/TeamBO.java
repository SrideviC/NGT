package com.capgemini.service;

import com.capgemini.bean.Player;
import com.capgemini.bean.Team;

public class TeamBO {
	public Team createTeam(String data, Player[] playerList)
	{
		String teaminfo[] = data.split(",");
		Team team = new Team();
		team.setName(teaminfo[0]);
		for(Player player : playerList) {
			if(player.getName().equalsIgnoreCase(teaminfo[1]))
				team.setPlayer(player);
		}
		return team;
	}
}
