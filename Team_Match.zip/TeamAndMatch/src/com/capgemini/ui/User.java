package com.capgemini.ui;

import java.util.Scanner;

import com.capgemini.bean.Match;
import com.capgemini.bean.Player;
import com.capgemini.bean.Team;
import com.capgemini.service.MatchBO;
import com.capgemini.service.PlayerBO;
import com.capgemini.service.TeamBO;

public class User {
	
	public static void main(String[] args) {
		PlayerBO player = new PlayerBO();
		TeamBO team = new TeamBO();
		MatchBO match = new MatchBO();
		
		Player[] players = new Player[20];
		Team[] teams = new Team[20];
		Match[] matchs = new Match[20];
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter player count:");
		int count = sc.nextInt();
		for(int i=1,k=0;i<=count;i++,k++) {
			System.out.println("Enter player "+ i + " details");
			String details = sc.next();
			players[k] = player.createPlayer(details);
			
		}
		
		System.out.println("Enter team count:");
		int count1 = sc.nextInt();
		for(int i=1,j=0;i<=count1;i++,j++)
		{
			System.out.println("Enter team "+ i + " details");
			String details = sc.next();
			teams[j] = team.createTeam(details, players);
		}
		
		System.out.println("Enter match count:");
		int count2 = sc.nextInt();
		for(int i=1,j=0;i<=count2;i++,j++)
		{
			System.out.println("Enter match "+ i + " details");
			String details = sc.next();
			matchs[j] = match.createMatch(details, teams);
		}
		
		while(true) {
			System.out.println("Menu:");
			System.out.println("1) Find Team");
		    System.out.println("2) ) Find All Matches In A Specific Venue");
		    System.out.println("Type 1 or 2");
		    System.out.println("Enter your choice");
		    int choice = sc.nextInt();
		    switch(choice) {
		    case 1:
		    	System.out.println("Enter Match Date");
			    String date = sc.next();
			    match.findTeam(date, matchs);
			    break;
	        case 2:
			    System.out.println("Enter team name:");
			    break;
			default:
			    System.out.println("Do you want to continue? Type Yes/No");
			    String choicee = sc.next();
			    if(choicee.equals("Yes")) {
			    	continue;
			    }
			    else {
				  System.out.println("Exit");
				  break;
			    }
		 }
	 }
  }
}
